<?php
/**
 * Plugin Name: DeepSeek Product Descriptions
 * Plugin URI: https://openrouter.ai
 * Description: Плагин для создания и улучшения описаний товаров WooCommerce с использованием AI моделей через OpenRouter
 * Version: 1.0.0
 * Author: OpenRouter Integration
 * Author URI: https://openrouter.ai
 * Requires at least: 5.6
 * Requires PHP: 7.4
 * Text Domain: deepseek-product-descriptions
 * Domain Path: /languages
 * License: GPL-2.0+
 */

if (!defined('ABSPATH')) {
    exit; // Выход при прямом доступе.
}

// Определение констант плагина
define('DEEPSEEK_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('DEEPSEEK_PLUGIN_URL', plugin_dir_url(__FILE__));
define('DEEPSEEK_VERSION', '1.0.0');

// Проверка, активен ли WooCommerce
function deepseek_check_woocommerce_active() {
    if (!class_exists('WooCommerce')) {
        add_action('admin_notices', function() {
            ?>
            <div class="notice notice-error">
                <p><?php _e('Для работы плагина "Генератор описаний товаров" требуется установить и активировать WooCommerce.', 'deepseek-product-descriptions'); ?></p>
            </div>
            <?php
        });
        return false;
    }
    return true;
}

// Подключение необходимых файлов
require_once DEEPSEEK_PLUGIN_DIR . 'includes/class-settings.php';
require_once DEEPSEEK_PLUGIN_DIR . 'includes/class-openrouter-api.php';

// Подключение скриптов и стилей админки
add_action('admin_enqueue_scripts', 'deepseek_enqueue_admin_assets');
function deepseek_enqueue_admin_assets($hook) {
    // Загружать только на странице товаров
    if ('edit.php' !== $hook || !isset($_GET['post_type']) || 'product' !== $_GET['post_type']) {
        return;
    }
    
    // Подключение Bootstrap CSS
    wp_enqueue_style('bootstrap-css', 'https://cdn.replit.com/agent/bootstrap-agent-dark-theme.min.css', array(), DEEPSEEK_VERSION);
    
    // Подключение CSS плагина
    wp_enqueue_style('deepseek-admin-css', DEEPSEEK_PLUGIN_URL . 'css/admin-style.css', array('bootstrap-css'), DEEPSEEK_VERSION);
    
    // Подключение JS плагина
    wp_enqueue_script('deepseek-admin-js', DEEPSEEK_PLUGIN_URL . 'js/deepseek.js', array('jquery'), DEEPSEEK_VERSION, true);
    
    // Подключаем модуль пакетной обработки
    wp_enqueue_script('deepseek-batch-js', DEEPSEEK_PLUGIN_URL . 'js/batch-processing.js', array('jquery', 'deepseek-admin-js'), DEEPSEEK_VERSION, true);
    
    // Локализация скрипта
    wp_localize_script('deepseek-admin-js', 'deepseek_data', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('deepseek_nonce'),
        'generating_text' => __('Генерация...', 'deepseek-product-descriptions'),
        'saving_text' => __('Сохранение...', 'deepseek-product-descriptions'),
        'success_text' => __('Успешно!', 'deepseek-product-descriptions'),
        'error_text' => __('Произошла ошибка', 'deepseek-product-descriptions'),
        'batch_generating' => __('Массовая генерация...', 'deepseek-product-descriptions'),
        'batch_complete' => __('Массовая генерация завершена', 'deepseek-product-descriptions'),
        'confirm_batch' => __('Вы уверены, что хотите сгенерировать описания для всех выбранных товаров?', 'deepseek-product-descriptions'),
        'selected_items' => __('выбрано', 'deepseek-product-descriptions'),
        'select_products_message' => __('Выберите товары для генерации описаний', 'deepseek-product-descriptions'),
        'generation_complete' => __('Генерация описаний завершена', 'deepseek-product-descriptions'),
        'processing_message' => __('Обработано {processed} из {total} ({percent}%)', 'deepseek-product-descriptions'),
        'completed_message' => __('Генерация описаний завершена', 'deepseek-product-descriptions'),
        'retry_message' => __('Повторная попытка...', 'deepseek-product-descriptions'),
        'has_desc_message' => __('Есть описание', 'deepseek-product-descriptions'),
    ));
}

// Инициализация плагина
function deepseek_init() {
    if (!deepseek_check_woocommerce_active()) {
        return;
    }
    
    // Инициализация настроек
    new DeepSeek_Settings();
    
    // Инициализация API обработчиков
    new DeepSeek_OpenRouter_API();
    
    // Добавление колонок товаров
    add_filter('manage_edit-product_columns', 'deepseek_add_product_columns');
    add_action('manage_product_posts_custom_column', 'deepseek_display_product_columns_content', 10, 2);
    
    // Добавление кнопок массовой генерации в верхней части таблицы товаров
    add_action('restrict_manage_posts', 'deepseek_add_batch_generate_buttons', 10, 2);
    
    // Добавление пакетных действий для товаров
    add_filter('bulk_actions-edit-product', 'deepseek_register_bulk_actions');
    add_filter('handle_bulk_actions-edit-product', 'deepseek_handle_bulk_actions', 10, 3);
    
    // Уведомления о завершении пакетной генерации
    add_action('admin_notices', 'deepseek_bulk_action_admin_notice');
}
add_action('plugins_loaded', 'deepseek_init');

// Добавление пользовательских колонок в таблицу товаров
function deepseek_add_product_columns($columns) {
    $new_columns = array();
    
    foreach ($columns as $key => $value) {
        $new_columns[$key] = $value;
        
        // Добавление наших колонок после колонки с названием
        if ($key === 'name') {
            $new_columns['deepseek_full_description'] = __('Полное описание', 'deepseek-product-descriptions');
            $new_columns['deepseek_short_description'] = __('Короткое описание', 'deepseek-product-descriptions');
        }
    }
    
    return $new_columns;
}

// Отображение содержимого в пользовательских колонках
function deepseek_display_product_columns_content($column, $post_id) {
    switch ($column) {
        case 'deepseek_full_description':
            $full_desc = get_post_meta($post_id, '_deepseek_full_description', true);
            $has_description = !empty($full_desc);
            
            echo '<div class="deepseek-description-container" data-id="' . esc_attr($post_id) . '">';
            
            // Максимально упрощенный интерфейс
            if ($has_description) {
                echo '<span class="status-dot has-desc" title="' . __('Есть описание', 'deepseek-product-descriptions') . '">•</span>';
            } else {
                echo '<span class="status-dot no-desc" title="' . __('Нет описания', 'deepseek-product-descriptions') . '">•</span>';
            }
            
            echo '<button type="button" class="ai-button generate-direct-full-desc" title="' . __('Быстрая генерация', 'deepseek-product-descriptions') . '">AI</button>';
            echo '<button type="button" class="edit-button edit-full-desc" title="' . __('Редактировать', 'deepseek-product-descriptions') . '">✎</button>';
            
            echo '<div class="full-desc-editor" style="display:none;">';
            echo '<div class="editor-container">';
            
            echo '<textarea class="old-full-desc" style="display:none;">' . esc_textarea($full_desc) . '</textarea>';
            echo '<textarea class="new-full-desc" placeholder="' . __('Сгенерированное описание', 'deepseek-product-descriptions') . '">' . esc_textarea($full_desc) . '</textarea>';
            
            echo '<div class="action-buttons">';
            echo '<button type="button" class="button generate-full-desc">↻</button>';
            echo '<button type="button" class="button button-primary save-full-desc">✓</button>';
            echo '<button type="button" class="button cancel-edit">✕</button>';
            echo '</div>'; // end action-buttons
            echo '<div class="response-message"></div>';
            echo '</div>'; // end editor-container
            echo '</div>'; // end full-desc-editor
            echo '</div>'; // end deepseek-description-container
            break;
            
        case 'deepseek_short_description':
            $short_desc = get_post_meta($post_id, '_deepseek_short_description', true);
            $has_description = !empty($short_desc);
            
            echo '<div class="deepseek-description-container" data-id="' . esc_attr($post_id) . '">';
            
            // Максимально упрощенный интерфейс
            if ($has_description) {
                echo '<span class="status-dot has-desc" title="' . __('Есть описание', 'deepseek-product-descriptions') . '">•</span>';
            } else {
                echo '<span class="status-dot no-desc" title="' . __('Нет описания', 'deepseek-product-descriptions') . '">•</span>';
            }
            
            echo '<button type="button" class="ai-button generate-direct-short-desc" title="' . __('Быстрая генерация', 'deepseek-product-descriptions') . '">AI</button>';
            echo '<button type="button" class="edit-button edit-short-desc" title="' . __('Редактировать', 'deepseek-product-descriptions') . '">✎</button>';
            
            echo '<div class="short-desc-editor" style="display:none;">';
            echo '<div class="editor-container">';
            
            echo '<textarea class="old-short-desc" style="display:none;">' . esc_textarea($short_desc) . '</textarea>';
            echo '<textarea class="new-short-desc" placeholder="' . __('Сгенерированное описание', 'deepseek-product-descriptions') . '">' . esc_textarea($short_desc) . '</textarea>';
            
            echo '<div class="action-buttons">';
            echo '<button type="button" class="button generate-short-desc">↻</button>';
            echo '<button type="button" class="button button-primary save-short-desc">✓</button>';
            echo '<button type="button" class="button cancel-edit">✕</button>';
            echo '</div>'; // end action-buttons
            echo '<div class="response-message"></div>';
            echo '</div>'; // end editor-container
            echo '</div>'; // end short-desc-editor
            echo '</div>'; // end deepseek-description-container
            break;
    }
}

// AJAX обработчик для генерации полного описания
add_action('wp_ajax_generate_full_description', 'deepseek_ajax_generate_full_description');
function deepseek_ajax_generate_full_description() {
    // Проверка nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'deepseek_nonce')) {
        wp_send_json_error(array('message' => __('Ошибка проверки безопасности', 'deepseek-product-descriptions')));
    }
    
    // Проверка необходимых данных
    if (!isset($_POST['post_id']) || !isset($_POST['current_description'])) {
        wp_send_json_error(array('message' => __('Отсутствуют необходимые данные', 'deepseek-product-descriptions')));
    }
    
    $post_id = intval($_POST['post_id']);
    $current_description = sanitize_textarea_field($_POST['current_description']);
    
    // Получение данных о товаре для контекста AI
    $product = wc_get_product($post_id);
    if (!$product) {
        wp_send_json_error(array('message' => __('Товар не найден', 'deepseek-product-descriptions')));
    }
    
    $product_name = $product->get_name();
    $product_categories = wp_get_post_terms($post_id, 'product_cat', array('fields' => 'names'));
    $product_tags = wp_get_post_terms($post_id, 'product_tag', array('fields' => 'names'));
    
    // Получение атрибутов товара
    $attributes = deepseek_get_product_attributes($product);
    
    // Подготовка контекста для AI
    $context = "Название товара: $product_name\n";
    
    if (!empty($product_categories)) {
        $context .= "Категории: " . implode(', ', $product_categories) . "\n";
    }
    
    if (!empty($product_tags)) {
        $context .= "Теги: " . implode(', ', $product_tags) . "\n";
    }
    
    // Добавляем информацию об атрибутах товара
    if (!empty($attributes)) {
        $context .= "Характеристики товара:\n";
        foreach ($attributes as $name => $value) {
            $context .= "- $name: $value\n";
        }
    }
    
    if (!empty($current_description)) {
        $context .= "Текущее описание: $current_description\n";
    }
    
    // Создание промпта для AI
    $prompt = "На основе следующей информации о товаре создайте подробное, привлекательное и оптимизированное для SEO описание товара, которое подчеркивает основные преимущества и характеристики. Сделайте его убедительным и соответствующим категории товара. Используйте ТОЛЬКО предоставленные характеристики товара, НЕ выдумывайте дополнительные характеристики или информацию. Стиль должен быть продающим, но без преувеличений. Пишите на русском языке:\n\n$context";
    
    // Инициализация обработчика API
    $api = new DeepSeek_OpenRouter_API();
    
    // Вызов API
    $response = $api->generate_text($prompt, 500);
    
    if (is_wp_error($response)) {
        wp_send_json_error(array('message' => $response->get_error_message()));
    }
    
    // Получение настроек и проверка флага принудительного автосохранения
    $settings = get_option('deepseek_settings', array());
    $auto_save = !empty($settings['auto_save_descriptions']) || !empty($_POST['auto_save']);
    
    // Если автосохранение включено или принудительно запрошено, сохраняем описание
    if ($auto_save) {
        $saved = update_post_meta($post_id, '_deepseek_full_description', $response);
        // Обновляем основное содержимое товара для совместимости
        $post_content = array(
            'ID' => $post_id,
            'post_content' => $response
        );
        wp_update_post($post_content);
    }
    
    wp_send_json_success(array(
        'description' => $response,
        'auto_saved' => $auto_save
    ));
}

// AJAX обработчик для генерации короткого описания
add_action('wp_ajax_generate_short_description', 'deepseek_ajax_generate_short_description');
function deepseek_ajax_generate_short_description() {
    // Проверка nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'deepseek_nonce')) {
        wp_send_json_error(array('message' => __('Ошибка проверки безопасности', 'deepseek-product-descriptions')));
    }
    
    // Проверка необходимых данных
    if (!isset($_POST['post_id']) || !isset($_POST['current_description'])) {
        wp_send_json_error(array('message' => __('Отсутствуют необходимые данные', 'deepseek-product-descriptions')));
    }
    
    $post_id = intval($_POST['post_id']);
    $current_description = sanitize_textarea_field($_POST['current_description']);
    
    // Получение данных о товаре для контекста AI
    $product = wc_get_product($post_id);
    if (!$product) {
        wp_send_json_error(array('message' => __('Товар не найден', 'deepseek-product-descriptions')));
    }
    
    $product_name = $product->get_name();
    $product_categories = wp_get_post_terms($post_id, 'product_cat', array('fields' => 'names'));

    // Получение атрибутов товара
    $attributes = deepseek_get_product_attributes($product);

    // Подготовка контекста для AI
    $context = "Название товара: $product_name\n";
    
    if (!empty($product_categories)) {
        $context .= "Категории: " . implode(', ', $product_categories) . "\n";
    }
    
    // Добавляем информацию об атрибутах товара
    if (!empty($attributes)) {
        $context .= "Характеристики товара:\n";
        foreach ($attributes as $name => $value) {
            $context .= "- $name: $value\n";
        }
    }
    
    if (!empty($current_description)) {
        $context .= "Текущее короткое описание: $current_description\n";
    }
    
    // Получение полного описания, если оно доступно, как дополнительный контекст
    $full_description = get_post_meta($post_id, '_deepseek_full_description', true);
    if (!empty($full_description)) {
        $context .= "Полное описание: $full_description\n";
    }
    
    // Создание промпта для AI
    $prompt = "На основе следующей информации о товаре создайте краткое и привлекательное короткое описание (1-2 предложения), которое передает суть товара и побуждает клиентов узнать больше. Используйте ТОЛЬКО предоставленные характеристики товара, НЕ добавляйте выдуманные данные. Опирайтесь строго на фактическую информацию о товаре. Пишите на русском языке:\n\n$context";
    
    // Инициализация обработчика API
    $api = new DeepSeek_OpenRouter_API();
    
    // Вызов API
    $response = $api->generate_text($prompt, 150);
    
    if (is_wp_error($response)) {
        wp_send_json_error(array('message' => $response->get_error_message()));
    }
    
    // Получение настроек и проверка флага принудительного автосохранения
    $settings = get_option('deepseek_settings', array());
    $auto_save = !empty($settings['auto_save_descriptions']) || !empty($_POST['auto_save']);
    
    // Если автосохранение включено или принудительно запрошено, сохраняем описание
    if ($auto_save) {
        $saved = update_post_meta($post_id, '_deepseek_short_description', $response);
        // Обновляем отрывок товара для совместимости
        $post_excerpt = array(
            'ID' => $post_id,
            'post_excerpt' => $response
        );
        wp_update_post($post_excerpt);
    }
    
    wp_send_json_success(array(
        'description' => $response,
        'auto_saved' => $auto_save
    ));
}

// AJAX обработчик для сохранения полного описания
add_action('wp_ajax_save_full_description', 'deepseek_ajax_save_full_description');
function deepseek_ajax_save_full_description() {
    // Проверка nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'deepseek_nonce')) {
        wp_send_json_error(array('message' => __('Ошибка проверки безопасности', 'deepseek-product-descriptions')));
    }
    
    // Проверка необходимых данных
    if (!isset($_POST['post_id']) || !isset($_POST['description'])) {
        wp_send_json_error(array('message' => __('Отсутствуют необходимые данные', 'deepseek-product-descriptions')));
    }
    
    $post_id = intval($_POST['post_id']);
    $description = wp_kses_post($_POST['description']);
    
    // Сохранение описания в мета-данных записи
    update_post_meta($post_id, '_deepseek_full_description', $description);
    
    // Получение настроек
    $settings = get_option('deepseek_settings', array());
    
    // Обновляем основное содержимое товара
    $post_data = array(
        'ID' => $post_id,
        'post_content' => $description
    );
    wp_update_post($post_data);
    
    wp_send_json_success(array('message' => __('Описание успешно сохранено', 'deepseek-product-descriptions')));
}

// AJAX обработчик для сохранения короткого описания
add_action('wp_ajax_save_short_description', 'deepseek_ajax_save_short_description');
function deepseek_ajax_save_short_description() {
    // Проверка nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'deepseek_nonce')) {
        wp_send_json_error(array('message' => __('Ошибка проверки безопасности', 'deepseek-product-descriptions')));
    }
    
    // Проверка необходимых данных
    if (!isset($_POST['post_id']) || !isset($_POST['description'])) {
        wp_send_json_error(array('message' => __('Отсутствуют необходимые данные', 'deepseek-product-descriptions')));
    }
    
    $post_id = intval($_POST['post_id']);
    $description = wp_kses_post($_POST['description']);
    
    // Сохранение описания в мета-данных записи
    update_post_meta($post_id, '_deepseek_short_description', $description);
    
    // Получение настроек
    $settings = get_option('deepseek_settings', array());
    
    // Обновляем выдержку товара
    $post_data = array(
        'ID' => $post_id,
        'post_excerpt' => $description
    );
    wp_update_post($post_data);
    
    wp_send_json_success(array('message' => __('Краткое описание успешно сохранено', 'deepseek-product-descriptions')));
}

// Регистрация хука активации
register_activation_hook(__FILE__, 'deepseek_activate');
function deepseek_activate() {
    // Создание настроек по умолчанию
    $default_settings = array(
        'openrouter_api_key' => '',
        'auto_save_descriptions' => false,
        'update_main_description' => true,
        'update_excerpt' => true,
        'use_local_api' => false,
        'local_api_url' => 'http://localhost:5000/api/generate',
    );
    
    // Добавление настроек только если они не существуют
    if (!get_option('deepseek_settings')) {
        add_option('deepseek_settings', $default_settings);
    }
}

// Регистрация хука деактивации
register_deactivation_hook(__FILE__, 'deepseek_deactivate');
function deepseek_deactivate() {
    // При необходимости здесь можно добавить код очистки
}

// Добавление кнопок массовой генерации на страницу товаров
function deepseek_add_batch_generate_buttons($post_type, $which) {
    // Проверяем, что мы на странице товаров и в верхней части
    if ('product' !== $post_type || 'top' !== $which) {
        return;
    }
    
    // Добавляем две отдельные кнопки пакетной генерации для разных типов описаний и чекбоксы для выбора товаров
    ?>
    <style>
    .deepseek-batch-status {
        margin-top: 15px;
        padding: 12px 15px;
        border-radius: 6px;
        background-color: #f0fff0;
        color: #006400;
        border: 1px solid #8bc34a;
        font-weight: bold;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        transition: all 0.3s ease;
    }
    
    .deepseek-progress-bar {
        height: 24px;
        background-color: #e9e9e9;
        border-radius: 12px;
        margin-top: 10px;
        overflow: hidden;
        box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.1);
    }
    
    .deepseek-progress-bar-inner {
        height: 100%;
        background: linear-gradient(to right, #4CAF50, #8bc34a);
        width: 0%;
        transition: width 0.5s ease;
        border-radius: 12px;
    }
    
    .deepseek-select-all-container {
        margin-bottom: 15px;
        padding: 10px 15px;
        background: #f0f7ff;
        border-radius: 6px;
        display: inline-flex;
        align-items: center;
        border-left: 4px solid #4285f4;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
        transition: all 0.3s ease;
        cursor: pointer;
    }
    
    .deepseek-select-all-container:hover {
        background: #e6f0ff;
        box-shadow: 0 3px 6px rgba(0, 0, 0, 0.1);
    }

    .deepseek-select-all-container input[type="checkbox"] {
        margin-right: 8px !important;
        transform: scale(1);
    }
    
    .deepseek-select-all-container span {
        font-weight: 500;
        font-size: 14px;
        color: #000000;
    }

    .deepseek-product-checkbox {
        margin-right: 8px !important;
        transform: scale(1);
    }
    
    .deepseek-buttons-container {
        display: flex;
        gap: 8px;
        margin-bottom: 15px;
        flex-wrap: wrap;
    }
    
    .deepseek-buttons-container button {
        padding: 8px 15px !important;
        font-weight: 500 !important;
        transition: all 0.2s ease !important;
        border-radius: 4px !important;
    }
    
    .deepseek-buttons-container button:hover {
        transform: translateY(-1px);
        box-shadow: 0 3px 5px rgba(0, 0, 0, 0.1);
    }
    
    /* Стиль для выделения выбранных товаров */
    .wp-list-table tbody tr.selected-for-generation {
        border: 2px solid #4CAF50 !important;
        box-shadow: 0 0 8px rgba(76, 175, 80, 0.6);
        transition: all 0.3s ease;
        background-color: rgba(76, 175, 80, 0.05);
    }
    
    /* Пунктирная рамка при наведении на товар */
    .wp-list-table tbody tr:hover {
        border: 1px dashed #4CAF50;
        background-color: rgba(76, 175, 80, 0.02);
    }
    
    /* Счетчик выбранных товаров */
    .deepseek-selected-count {
        margin-left: 10px;
        background: #4CAF50;
        color: white;
        border-radius: 20px;
        padding: 2px 8px;
        font-size: 12px;
        font-weight: bold;
        display: none;
    }
    </style>
    
    <div class="alignleft actions deepseek-generator-controls">
        <div class="deepseek-select-all-container">
            <label>
                <input type="checkbox" id="deepseek-select-all-products" />
                <span><?php _e('Выбрать все товары на странице', 'deepseek-product-descriptions'); ?></span>
            </label>
            <span class="deepseek-selected-count">0</span>
        </div>
        <div class="deepseek-buttons-container">
            <button type="button" id="deepseek-batch-generate-full" class="button button-primary">
                <span class="dashicons dashicons-format-aside" style="margin-right: 5px; font-size: 16px; vertical-align: text-bottom;"></span>
                <?php _e('Генерировать полные описания', 'deepseek-product-descriptions'); ?>
            </button>
            <button type="button" id="deepseek-batch-generate-short" class="button button-primary">
                <span class="dashicons dashicons-editor-paragraph" style="margin-right: 5px; font-size: 16px; vertical-align: text-bottom;"></span>
                <?php _e('Генерировать короткие описания', 'deepseek-product-descriptions'); ?>
            </button>
            <button type="button" id="deepseek-batch-generate-both" class="button button-primary" style="background: #2271b1; border-color: #135e96; color: white;">
                <span class="dashicons dashicons-welcome-write-blog" style="margin-right: 5px; font-size: 16px; vertical-align: text-bottom;"></span>
                <?php _e('Генерировать оба описания', 'deepseek-product-descriptions'); ?>
            </button>
        </div>
    </div>
    
    <script>
    jQuery(document).ready(function($) {
        // Добавляем чекбоксы к каждому товару и сохраняем ссылки на них
        const checkboxMap = {}; // Объект для хранения соответствия ID товара и чекбокса
        
        $('.wp-list-table tbody tr').each(function() {
            // Получаем ID товара из стандартного чекбокса WordPress
            const wpCheckbox = $(this).find('.check-column input[type="checkbox"]');
            const productId = wpCheckbox.val();
            
            if (productId) {
                // Добавляем наш собственный чекбокс сразу после стандартного
                // и сохраняем ссылку на него для быстрого доступа
                const deepseekCheckbox = $(`<input type="checkbox" class="deepseek-product-checkbox" 
                                         data-product-id="${productId}" 
                                         style="margin-left: 5px;" />`);
                wpCheckbox.after(deepseekCheckbox);
                
                // Сохраняем соответствие в объекте
                checkboxMap[productId] = deepseekCheckbox;
                
                // Связываем чекбокс с визуальными индикаторами в обеих колонках
                // Привязываем наш чекбокс к контейнерам описаний для этого товара
                const containers = $(`.deepseek-description-container[data-id="${productId}"]`);
                containers.attr('data-selected', 'false');
                
                // При клике на чекбокс подсвечиваем соответствующую строку и добавляем рамку
                deepseekCheckbox.on('change', function() {
                    const row = $(this).closest('tr');
                    if ($(this).is(':checked')) {
                        row.css('background-color', '#f7fff7');
                        row.addClass('selected-for-generation');
                        containers.attr('data-selected', 'true');
                    } else {
                        row.css('background-color', '');
                        row.removeClass('selected-for-generation');
                        containers.attr('data-selected', 'false');
                    }
                });
            }
        });
        
        // Обработчик выбора всех товаров
        $('#deepseek-select-all-products').on('change', function() {
            const isChecked = $(this).prop('checked');
            
            // Устанавливаем состояние для всех чекбоксов
            $('.deepseek-product-checkbox').each(function() {
                $(this).prop('checked', isChecked);
                
                // Вызываем событие change чтобы сработали обработчики выделения строк
                $(this).trigger('change');
            });
        });
        
        // Функция для обновления счетчика выбранных товаров
        function updateSelectedCounter() {
            const selectedCount = $('.deepseek-product-checkbox:checked').length;
            const counterEl = $('.deepseek-selected-count');
            
            if (selectedCount > 0) {
                counterEl.text(selectedCount + ' ' + deepseek_data.selected_items).show();
            } else {
                counterEl.hide();
            }
            
            // Активируем/деактивируем кнопки генерации в зависимости от выбора
            if (selectedCount > 0) {
                $('.deepseek-buttons-container button').prop('disabled', false);
            } else {
                $('.deepseek-buttons-container button').prop('disabled', true);
            }
        }
        
        // Вызываем обновление счетчика при изменении чекбоксов
        $(document).on('change', '.deepseek-product-checkbox', function() {
            updateSelectedCounter();
        });
        
        // Получение выбранных ID товаров
        function getSelectedProductIds() {
            const selectedIds = [];
            $('.deepseek-product-checkbox:checked').each(function() {
                const productId = parseInt($(this).data('product-id'));
                if (productId && selectedIds.indexOf(productId) === -1) {
                    selectedIds.push(productId);
                }
            });
            
            // Если ничего не выбрано, добавим отладочное сообщение
            console.log('Выбранные ID товаров:', selectedIds);
            
            // Обновляем счетчик выбранных товаров
            updateSelectedCounter();
            
            return selectedIds;
        }
        
        // Обработчик кнопки массовой генерации полных описаний
        $('#deepseek-batch-generate-full').on('click', function() {
            const selectedIds = getSelectedProductIds();
            
            if (selectedIds.length === 0) {
                alert('<?php _e('Выберите товары для генерации описаний', 'deepseek-product-descriptions'); ?>');
                return;
            }
            
            // Подтверждение перед началом массовой генерации
            if (confirm(deepseek_data.confirm_batch)) {
                // Запускаем пакетную обработку только для полных описаний
                batchGenerateFullDescriptions(selectedIds);
            }
        });
        
        // Обработчик кнопки массовой генерации коротких описаний
        $('#deepseek-batch-generate-short').on('click', function() {
            const selectedIds = getSelectedProductIds();
            
            if (selectedIds.length === 0) {
                alert('<?php _e('Выберите товары для генерации описаний', 'deepseek-product-descriptions'); ?>');
                return;
            }
            
            // Подтверждение перед началом массовой генерации
            if (confirm(deepseek_data.confirm_batch)) {
                // Запускаем пакетную обработку только для коротких описаний
                batchGenerateShortDescriptions(selectedIds);
            }
        });
        
        // Обработчик кнопки массовой генерации обоих описаний
        $('#deepseek-batch-generate-both').on('click', function() {
            const selectedIds = getSelectedProductIds();
            
            if (selectedIds.length === 0) {
                alert('<?php _e('Выберите товары для генерации описаний', 'deepseek-product-descriptions'); ?>');
                return;
            }
            
            console.log('Запускаем генерацию обоих описаний для выбранных товаров:', selectedIds);
            
            // Подтверждение перед началом массовой генерации
            if (confirm(deepseek_data.confirm_batch)) {
                // Запускаем пакетную обработку для обоих типов описаний
                batchGenerateBothDescriptions(selectedIds);
            }
        });
        
        // Функция для пакетной генерации обоих описаний
        function batchGenerateBothDescriptions(productIds) {
            console.log('Запуск batchGenerateBothDescriptions для товаров:', productIds);
            
            if (!productIds || productIds.length === 0) {
                console.error('Нет товаров для генерации!');
                alert('<?php _e('Выберите товары для генерации описаний', 'deepseek-product-descriptions'); ?>');
                return;
            }
            
            let processed = 0;
            let total = productIds.length * 2; // Два описания для каждого товара
            let statusContainer = $('<div class="deepseek-batch-status"></div>');
            let progressBar = $('<div class="deepseek-progress-bar"><div class="deepseek-progress-bar-inner"></div></div>');
            
            // Удаляем предыдущие статус-бары, если они есть
            $('.deepseek-batch-status').remove();
            
            // Добавляем статус-бар в верхнюю часть страницы
            $('.tablenav.top').after(statusContainer);
            statusContainer.append(progressBar);
            
            // Инициализируем статус
            updateStatus();
            
            // Выделяем визуально выбранные товары
            productIds.forEach(function(pid) {
                $(`.wp-list-table tbody tr input[value="${pid}"]`).closest('tr').addClass('selected-for-generation');
            });
            
            // Обрабатываем каждый товар последовательно
            console.log('Начинаем обработку товаров...');
            processNext(0);
            
            function processNext(index) {
                console.log('processNext с индексом', index, 'из', productIds.length);
                
                if (index >= productIds.length) {
                    console.log('Обработка завершена');
                    statusContainer.html('<?php _e('Генерация всех описаний завершена', 'deepseek-product-descriptions'); ?>');
                    setTimeout(function() {
                        statusContainer.fadeOut();
                    }, 3000);
                    return;
                }
                
                const productId = productIds[index];
                console.log('Обрабатываем товар ID:', productId);
                
                // Сначала генерируем полное описание, потом короткое
                generateFullDescription(productId, function() {
                    processed++;
                    updateStatus();
                    console.log('Полное описание сгенерировано, переходим к короткому');
                    
                    generateShortDescription(productId, function() {
                        processed++;
                        updateStatus();
                        console.log('Короткое описание сгенерировано, переходим к следующему товару');
                        // Переходим к следующему товару
                        processNext(index + 1);
                    });
                });
            }
            
            function updateStatus() {
                const percent = Math.round((processed / total) * 100);
                statusContainer.find('.deepseek-progress-bar-inner').css('width', percent + '%');
                statusContainer.html('');
                statusContainer.append(`<div><?php _e('Прогресс генерации: ', 'deepseek-product-descriptions'); ?> ${processed}/${total} (${percent}%)</div>`);
                statusContainer.append(progressBar);
            }
            
            // Функции generateFullDescription и generateShortDescription как в других обработчиках
            function generateFullDescription(productId, callback) {
                console.log('Генерация полного описания для товара ID:', productId);
                
                // Находим строку товара
                const row = $(`.wp-list-table tbody tr input[value="${productId}"]`).closest('tr');
                row.css('background-color', '#f0fff0'); // Зеленый фон строки для индикации обработки
                
                // Дополнительная отладка для поиска контейнера
                let containerCount = $(`.deepseek-description-container[data-id="${productId}"]`).length;
                console.log(`Найдено контейнеров с data-id=${productId}: ${containerCount}`);
                
                // Если контейнер не найден по data-id, попробуем найти через родительскую строку
                let container;
                if (containerCount === 0) {
                    console.log('Пытаемся найти контейнер через row...');
                    container = row.find('.deepseek-description-container').first();
                    if (container.length === 0) {
                        console.error(`Не удалось найти контейнер для товара ID: ${productId}`);
                        if (typeof callback === 'function') callback();
                        return;
                    }
                } else {
                    container = $(`.deepseek-description-container[data-id="${productId}"]`).first();
                }
                
                // Проверяем наличие текстовой области
                let textareaExists = container.find('.old-full-desc').length > 0;
                console.log(`Текстовая область найдена: ${textareaExists}`);
                
                const currentDescription = textareaExists ? 
                    (container.find('.old-full-desc').val() || '') : 
                    '';
                
                $.ajax({
                    url: deepseek_data.ajax_url,
                    type: 'POST',
                    data: {
                        action: 'generate_full_description',
                        post_id: productId,
                        current_description: currentDescription,
                        nonce: deepseek_data.nonce,
                        auto_save: true // Принудительное автосохранение
                    },
                    success: function(response) {
                        if (response.success) {
                            // Обновляем индикатор
                            container.find('.status-dot')
                                .removeClass('no-desc')
                                .addClass('has-desc')
                                .attr('title', '<?php _e('Есть описание', 'deepseek-product-descriptions'); ?>')
                                .text('•');
                                
                            // Переходим к следующему шагу
                            if (typeof callback === 'function') callback();
                        } else {
                            console.error('Ошибка генерации полного описания для товара ID:', productId, response.data.message);
                            row.css('background-color', '#fff0f0'); // Красный фон при ошибке
                            if (typeof callback === 'function') callback();
                        }
                    },
                    error: function() {
                        console.error('Ошибка AJAX запроса для товара ID:', productId);
                        row.css('background-color', '#fff0f0'); // Красный фон при ошибке
                        if (typeof callback === 'function') callback();
                    }
                });
            }
            
            function generateShortDescription(productId, callback) {
                console.log('Генерация короткого описания для товара ID:', productId);
                
                // Находим строку товара
                const row = $(`.wp-list-table tbody tr input[value="${productId}"]`).closest('tr');
                row.css('background-color', '#f0fff0'); // Зеленый фон строки для индикации обработки
                
                // Дополнительная отладка для поиска контейнера
                let containerCount = $(`.deepseek-description-container[data-id="${productId}"]`).length;
                console.log(`Найдено контейнеров с data-id=${productId}: ${containerCount}`);
                
                // Если контейнер не найден по data-id, попробуем найти через родительскую строку
                let container;
                if (containerCount < 2) {
                    console.log('Пытаемся найти контейнер для короткого описания через row...');
                    // Находим все контейнеры в строке
                    const rowContainers = row.find('.deepseek-description-container');
                    console.log(`В строке найдено контейнеров: ${rowContainers.length}`);
                    
                    // Берем второй контейнер, если он есть, иначе первый
                    container = rowContainers.length > 1 ? rowContainers.eq(1) : rowContainers.first();
                    
                    if (container.length === 0) {
                        console.error(`Не удалось найти контейнер для короткого описания товара ID: ${productId}`);
                        if (typeof callback === 'function') callback();
                        return;
                    }
                } else {
                    // Если есть несколько контейнеров, берем второй (для короткого описания)
                    container = $(`.deepseek-description-container[data-id="${productId}"]`).eq(1);
                }
                
                // Проверяем наличие текстовой области
                let textareaExists = container.find('.old-short-desc').length > 0;
                console.log(`Текстовая область для короткого описания найдена: ${textareaExists}`);
                
                const currentDescription = textareaExists ? 
                    (container.find('.old-short-desc').val() || '') : 
                    '';
                
                $.ajax({
                    url: deepseek_data.ajax_url,
                    type: 'POST',
                    data: {
                        action: 'generate_short_description',
                        post_id: productId,
                        current_description: currentDescription,
                        nonce: deepseek_data.nonce,
                        auto_save: true // Принудительное автосохранение
                    },
                    success: function(response) {
                        if (response.success) {
                            // Обновляем индикатор
                            container.find('.status-dot')
                                .removeClass('no-desc')
                                .addClass('has-desc')
                                .attr('title', '<?php _e('Есть описание', 'deepseek-product-descriptions'); ?>')
                                .text('•');
                                
                            // Переходим к следующему шагу
                            if (typeof callback === 'function') callback();
                        } else {
                            console.error('Ошибка генерации короткого описания для товара ID:', productId, response.data.message);
                            if (typeof callback === 'function') callback();
                        }
                    },
                    error: function() {
                        console.error('Ошибка AJAX запроса для товара ID:', productId);
                        if (typeof callback === 'function') callback();
                    }
                });
            }
        }
        
        // Функция для пакетной генерации полных описаний
        function batchGenerateFullDescriptions(productIds) {
            let processed = 0;
            let total = productIds.length;
            let statusContainer = $('<div class="deepseek-batch-status"></div>');
            let progressBar = $('<div class="deepseek-progress-bar"><div class="deepseek-progress-bar-inner"></div></div>');
            
            // Добавляем статус-бар в верхнюю часть страницы
            $('.tablenav.top').after(statusContainer);
            statusContainer.append(progressBar);
            updateStatus();
            
            // Обрабатываем каждый товар последовательно
            processNext(0);
            
            function processNext(index) {
                if (index >= productIds.length) {
                    statusContainer.html('<?php _e('Генерация полных описаний завершена', 'deepseek-product-descriptions'); ?>');
                    setTimeout(function() {
                        statusContainer.fadeOut();
                    }, 3000);
                    return;
                }
                
                const productId = productIds[index];
                generateFullDescription(productId, function() {
                    processed++;
                    updateStatus();
                    // Переходим к следующему товару
                    processNext(index + 1);
                });
            }
            
            function updateStatus() {
                const percent = Math.round((processed / total) * 100);
                statusContainer.find('.deepseek-progress-bar-inner').css('width', percent + '%');
                statusContainer.prepend(`<div><?php _e('Генерация полных описаний: ', 'deepseek-product-descriptions'); ?> ${processed}/${total} (${percent}%)</div>`);
            }
            
            function generateFullDescription(productId, callback) {
                console.log('Функция batchGenerateFullDescriptions: Генерация полного описания для товара ID:', productId);
                
                // Находим строку товара
                const row = $(`.wp-list-table tbody tr input[value="${productId}"]`).closest('tr');
                row.css('background-color', '#f0fff0'); // Зеленый фон строки для индикации обработки
                
                // Дополнительная отладка для поиска контейнера
                let containerCount = $(`.deepseek-description-container[data-id="${productId}"]`).length;
                console.log(`Найдено контейнеров с data-id=${productId}: ${containerCount}`);
                
                // Если контейнер не найден по data-id, попробуем найти через родительскую строку
                let container;
                if (containerCount === 0) {
                    console.log('Пытаемся найти контейнер через row...');
                    container = row.find('.deepseek-description-container').first();
                    if (container.length === 0) {
                        console.error(`Не удалось найти контейнер для товара ID: ${productId}`);
                        if (typeof callback === 'function') callback();
                        return;
                    }
                } else {
                    container = $(`.deepseek-description-container[data-id="${productId}"]`).first();
                }
                
                // Проверяем наличие текстовой области
                let textareaExists = container.find('.old-full-desc').length > 0;
                console.log(`Текстовая область найдена: ${textareaExists}`);
                
                const currentDescription = textareaExists ? 
                    (container.find('.old-full-desc').val() || '') : 
                    '';
                
                $.ajax({
                    url: deepseek_data.ajax_url,
                    type: 'POST',
                    data: {
                        action: 'generate_full_description',
                        post_id: productId,
                        current_description: currentDescription,
                        nonce: deepseek_data.nonce,
                        auto_save: true // Принудительное автосохранение
                    },
                    success: function(response) {
                        if (response.success) {
                            // Обновляем индикатор
                            container.find('.status-dot')
                                .removeClass('no-desc')
                                .addClass('has-desc')
                                .attr('title', '<?php _e('Есть описание', 'deepseek-product-descriptions'); ?>')
                                .text('•');
                                
                            // Возвращаем нормальный цвет фона через 1 секунду
                            setTimeout(function() {
                                row.css('background-color', '');
                            }, 1000);
                                
                            // Переходим к следующему шагу
                            if (typeof callback === 'function') callback();
                        } else {
                            console.error('Ошибка генерации полного описания для товара ID:', productId, response.data.message);
                            row.css('background-color', '#fff0f0'); // Красный фон при ошибке
                            if (typeof callback === 'function') callback();
                        }
                    },
                    error: function() {
                        console.error('Ошибка AJAX запроса для товара ID:', productId);
                        row.css('background-color', '#fff0f0'); // Красный фон при ошибке
                        if (typeof callback === 'function') callback();
                    }
                });
            }
        }
        
        // Функция для пакетной генерации коротких описаний
        function batchGenerateShortDescriptions(productIds) {
            let processed = 0;
            let total = productIds.length;
            let statusContainer = $('<div class="deepseek-batch-status"></div>');
            let progressBar = $('<div class="deepseek-progress-bar"><div class="deepseek-progress-bar-inner"></div></div>');
            
            // Добавляем статус-бар в верхнюю часть страницы
            $('.tablenav.top').after(statusContainer);
            statusContainer.append(progressBar);
            updateStatus();
            
            // Обрабатываем каждый товар последовательно
            processNext(0);
            
            function processNext(index) {
                if (index >= productIds.length) {
                    statusContainer.html('<?php _e('Генерация коротких описаний завершена', 'deepseek-product-descriptions'); ?>');
                    setTimeout(function() {
                        statusContainer.fadeOut();
                    }, 3000);
                    return;
                }
                
                const productId = productIds[index];
                generateShortDescription(productId, function() {
                    processed++;
                    updateStatus();
                    // Переходим к следующему товару
                    processNext(index + 1);
                });
            }
            
            function updateStatus() {
                const percent = Math.round((processed / total) * 100);
                statusContainer.find('.deepseek-progress-bar-inner').css('width', percent + '%');
                statusContainer.prepend(`<div><?php _e('Генерация коротких описаний: ', 'deepseek-product-descriptions'); ?> ${processed}/${total} (${percent}%)</div>`);
            }
            
            function generateShortDescription(productId, callback) {
                console.log('Функция batchGenerateShortDescriptions: Генерация короткого описания для товара ID:', productId);
                
                // Находим строку товара
                const row = $(`.wp-list-table tbody tr input[value="${productId}"]`).closest('tr');
                row.css('background-color', '#f0fff0'); // Зеленый фон строки для индикации обработки
                
                // Дополнительная отладка для поиска контейнера
                let containerCount = $(`.deepseek-description-container[data-id="${productId}"]`).length;
                console.log(`Найдено контейнеров с data-id=${productId}: ${containerCount}`);
                
                // Если контейнер не найден по data-id или их меньше 2, попробуем найти через родительскую строку
                let container;
                if (containerCount < 2) {
                    console.log('Пытаемся найти контейнер для короткого описания через row...');
                    // Находим все контейнеры в строке
                    const rowContainers = row.find('.deepseek-description-container');
                    console.log(`В строке найдено контейнеров: ${rowContainers.length}`);
                    
                    // Берем второй контейнер, если он есть, иначе первый
                    container = rowContainers.length > 1 ? rowContainers.eq(1) : rowContainers.first();
                    
                    if (container.length === 0) {
                        console.error(`Не удалось найти контейнер для короткого описания товара ID: ${productId}`);
                        if (typeof callback === 'function') callback();
                        return;
                    }
                } else {
                    // Если есть несколько контейнеров, берем второй (для короткого описания)
                    container = $(`.deepseek-description-container[data-id="${productId}"]`).eq(1);
                }
                
                // Проверяем наличие текстовой области
                let textareaExists = container.find('.old-short-desc').length > 0;
                console.log(`Текстовая область для короткого описания найдена: ${textareaExists}`);
                
                const currentDescription = textareaExists ? 
                    (container.find('.old-short-desc').val() || '') : 
                    '';
                
                $.ajax({
                    url: deepseek_data.ajax_url,
                    type: 'POST',
                    data: {
                        action: 'generate_short_description',
                        post_id: productId,
                        current_description: currentDescription,
                        nonce: deepseek_data.nonce,
                        auto_save: true // Принудительное автосохранение
                    },
                    success: function(response) {
                        if (response.success) {
                            // Обновляем индикатор
                            container.find('.status-dot')
                                .removeClass('no-desc')
                                .addClass('has-desc')
                                .attr('title', '<?php _e('Есть описание', 'deepseek-product-descriptions'); ?>')
                                .text('•');
                                
                            // Возвращаем нормальный цвет фона через 1 секунду
                            setTimeout(function() {
                                row.css('background-color', '');
                            }, 1000);
                                
                            // Переходим к следующему шагу
                            if (typeof callback === 'function') callback();
                        } else {
                            console.error('Ошибка генерации короткого описания для товара ID:', productId, response.data.message);
                            row.css('background-color', '#fff0f0'); // Красный фон при ошибке
                            if (typeof callback === 'function') callback();
                        }
                    },
                    error: function() {
                        console.error('Ошибка AJAX запроса для товара ID:', productId);
                        row.css('background-color', '#fff0f0'); // Красный фон при ошибке
                        if (typeof callback === 'function') callback();
                    }
                });
            }
        }
    });
    </script>
    <?php
}

// Функция для получения атрибутов и характеристик товара
function deepseek_get_product_attributes($product) {
    if (!$product) {
        return array();
    }
    
    $attributes = array();
    
    // Получаем атрибуты товара (общие и пользовательские)
    $wc_attributes = $product->get_attributes();
    
    if (!empty($wc_attributes)) {
        foreach ($wc_attributes as $attribute) {
            // Если это таксономия
            if ($attribute->is_taxonomy()) {
                $attribute_taxonomy = $attribute->get_taxonomy_object();
                $attribute_values = array();
                
                // Получаем значения атрибута
                $attribute_terms = wc_get_product_terms(
                    $product->get_id(),
                    $attribute->get_name(),
                    array('fields' => 'names')
                );
                
                if (!empty($attribute_terms)) {
                    $attribute_name = wc_attribute_label($attribute->get_name()); // Получаем название атрибута
                    $attributes[$attribute_name] = implode(', ', $attribute_terms);
                }
            } else {
                // Пользовательские атрибуты (не таксономии)
                $attribute_name = $attribute->get_name();
                $attribute_options = $attribute->get_options();
                
                if (!empty($attribute_options) && is_array($attribute_options)) {
                    $attributes[$attribute_name] = implode(', ', $attribute_options);
                }
            }
        }
    }
    
    // Добавляем мета-данные как дополнительные характеристики
    $meta_data = $product->get_meta_data();
    foreach ($meta_data as $meta) {
        $data = $meta->get_data();
        
        // Фильтруем служебные мета-данные (начинающиеся с "_")
        if (!empty($data['key']) && substr($data['key'], 0, 1) !== '_') {
            // Получаем удобочитаемое название и значение
            $meta_value = $data['value'];
            
            // Пропускаем пустые значения или массивы/объекты
            if (!empty($meta_value) && (is_string($meta_value) || is_numeric($meta_value))) {
                $attributes[$data['key']] = $meta_value;
            }
        }
    }
    
    return $attributes;
}

// Регистрация пакетных действий для товаров
function deepseek_register_bulk_actions($bulk_actions) {
    $bulk_actions['generate_both_descriptions'] = __('Сгенерировать оба описания', 'deepseek-product-descriptions');
    $bulk_actions['generate_full_descriptions'] = __('Сгенерировать полное описание', 'deepseek-product-descriptions');
    $bulk_actions['generate_short_descriptions'] = __('Сгенерировать короткое описание', 'deepseek-product-descriptions');
    return $bulk_actions;
}

// Обработка пакетных действий
function deepseek_handle_bulk_actions($redirect_to, $action, $post_ids) {
    if (!in_array($action, ['generate_both_descriptions', 'generate_full_descriptions', 'generate_short_descriptions'])) {
        return $redirect_to;
    }
    
    $processed = 0;
    $api = new DeepSeek_OpenRouter_API();
    
    foreach ($post_ids as $post_id) {
        // Пропускаем, если не товар
        if (get_post_type($post_id) !== 'product') {
            continue;
        }
        
        // Получение данных о товаре
        $product = wc_get_product($post_id);
        $product_name = $product->get_name();
        $product_categories = wp_get_post_terms($post_id, 'product_cat', array('fields' => 'names'));
        $product_tags = wp_get_post_terms($post_id, 'product_tag', array('fields' => 'names'));
        
        // Получение атрибутов товара
        $attributes = deepseek_get_product_attributes($product);
        
        // Генерация полного описания
        if ($action === 'generate_both_descriptions' || $action === 'generate_full_descriptions') {
            // Подготовка контекста для AI
            $context = "Название товара: $product_name\n";
            
            if (!empty($product_categories)) {
                $context .= "Категории: " . implode(', ', $product_categories) . "\n";
            }
            
            if (!empty($product_tags)) {
                $context .= "Теги: " . implode(', ', $product_tags) . "\n";
            }
            
            // Добавляем информацию об атрибутах товара
            if (!empty($attributes)) {
                $context .= "Характеристики товара:\n";
                foreach ($attributes as $name => $value) {
                    $context .= "- $name: $value\n";
                }
            }
            
            // Создание промпта для AI
            $prompt = "На основе следующей информации о товаре создайте подробное, привлекательное и оптимизированное для SEO описание товара, которое подчеркивает основные преимущества и характеристики. Сделайте его убедительным и соответствующим категории товара. Используйте ТОЛЬКО предоставленные характеристики товара, НЕ выдумывайте дополнительные характеристики или информацию. Стиль должен быть продающим, но без преувеличений. Пишите на русском языке:\n\n$context";
            
            // Вызов API
            $response = $api->generate_text($prompt, 500);
            
            // Сохранение описания, если нет ошибок
            if (!is_wp_error($response)) {
                update_post_meta($post_id, '_deepseek_full_description', $response);
                
                // Обновляем основное содержимое товара
                $post_content = array(
                    'ID' => $post_id,
                    'post_content' => $response
                );
                wp_update_post($post_content);
                
                $processed++;
            }
        }
        
        // Генерация короткого описания
        if ($action === 'generate_both_descriptions' || $action === 'generate_short_descriptions') {
            // Подготовка контекста для AI
            $context = "Название товара: $product_name\n";
            
            if (!empty($product_categories)) {
                $context .= "Категории: " . implode(', ', $product_categories) . "\n";
            }
            
            // Добавляем информацию об атрибутах товара
            if (!empty($attributes)) {
                $context .= "Характеристики товара:\n";
                foreach ($attributes as $name => $value) {
                    $context .= "- $name: $value\n";
                }
            }
            
            // Получение полного описания, если оно доступно
            $full_description = get_post_meta($post_id, '_deepseek_full_description', true);
            if (!empty($full_description)) {
                $context .= "Полное описание: $full_description\n";
            }
            
            // Создание промпта для AI
            $prompt = "На основе следующей информации о товаре создайте краткое и привлекательное короткое описание (1-2 предложения), которое передает суть товара и побуждает клиентов узнать больше. Используйте ТОЛЬКО предоставленные характеристики товара, НЕ добавляйте выдуманные данные. Опирайтесь строго на фактическую информацию о товаре. Пишите на русском языке:\n\n$context";
            
            // Вызов API
            $response = $api->generate_text($prompt, 150);
            
            // Сохранение описания, если нет ошибок
            if (!is_wp_error($response)) {
                update_post_meta($post_id, '_deepseek_short_description', $response);
                
                // Обновляем отрывок товара
                $post_excerpt = array(
                    'ID' => $post_id,
                    'post_excerpt' => $response
                );
                wp_update_post($post_excerpt);
                
                $processed++;
            }
        }
    }
    
    // Добавляем информацию о количестве обработанных товаров
    $redirect_to = add_query_arg('deepseek_processed', $processed, $redirect_to);
    $redirect_to = add_query_arg('deepseek_action', $action, $redirect_to);
    
    return $redirect_to;
}

// Показ уведомления о результатах обработки
function deepseek_bulk_action_admin_notice() {
    if (!empty($_REQUEST['deepseek_processed'])) {
        $processed = intval($_REQUEST['deepseek_processed']);
        $action = $_REQUEST['deepseek_action'] ?? '';
        
        $action_text = '';
        switch ($action) {
            case 'generate_both_descriptions':
                $action_text = __('Генерация обоих описаний', 'deepseek-product-descriptions');
                break;
            case 'generate_full_descriptions':
                $action_text = __('Генерация полных описаний', 'deepseek-product-descriptions');
                break;
            case 'generate_short_descriptions':
                $action_text = __('Генерация коротких описаний', 'deepseek-product-descriptions');
                break;
        }
        
        printf(
            '<div class="notice notice-success is-dismissible"><p>' . 
            __('%s: Успешно обработано %d товаров.', 'deepseek-product-descriptions') . 
            '</p></div>',
            esc_html($action_text),
            esc_html($processed)
        );
    }
}